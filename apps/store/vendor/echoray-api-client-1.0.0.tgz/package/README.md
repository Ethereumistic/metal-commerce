# Public catalog client 1.0.0

Use `@echoray/api-client/public-catalog` for public commerce data. This entrypoint
contains no private adapter, backend credentials, dependency on the monorepo at
runtime, or additional server cache. Keep private commerce on its existing adapter.

```ts
import { createPublicCatalogClient, CatalogError } from '@echoray/api-client/public-catalog';
const catalog = createPublicCatalogClient({
  gatewayUrl: 'https://commerce.echoray.io',
  storefrontId: process.env.PUBLIC_STOREFRONT_INTEGRATION_ID!,
  // On Workers, optionally use binding: env.COMMERCE_GATEWAY.
});
const boot = await catalog.bootstrap();
const page = await catalog.products({ limit: 24, collection: 'Chairs', sort: 'name-asc' });
const next = page.data.cursor
  ? await catalog.products({ limit: 24, collection: 'Chairs', sort: 'name-asc', cursor: page.data.cursor })
  : null;
const detail = await catalog.detail('example-chair');
const imageUrl = catalog.imageUrl(detail.data.product.images[0], 'card');
```

Build the standalone distribution with `pnpm --filter @echoray/api-client build:public`,
then use `npm pack --ignore-scripts` in `packages/api-client/dist/public`. Install the
resulting `echoray-api-client-1.0.0.tgz` in a separate checkout. The committed release
is at `packages/api-client/releases/echoray-api-client-1.0.0.tgz`. The generated package
has zero dependencies; its declarations are emitted from the shared validators
without running TypeScript checks. The monorepo root/client exports remain unchanged.
The distribution can also be published to an authorized registry later.

`bootstrap`, `collections`, `products`, `detail`, `availability` and `sitemap`
accept cancellation signals. `CatalogError` includes an HTTP status, typed backend
code and retry delay; `restartPagination` means discard the cursor and reload page
one. No implicit retry or unlimited direct-origin fallback exists.

Discovery applies category, normalized material and name/search ordering on the
backend before pagination. Category names use their exact backend spelling. Material
comes from Material/Materials/Matériau/Matériaux/Matière/Werkstoff specifications,
mapped centrally to wood (oak/wood/walnut/timber/ash), fabric (fabric/linen/upholstery),
metal (metal/steel/brass), or glass (glass/mirror), matching MORIS. Unknown values
remain unclassified. Name sorting uses NFKC lowercase codepoint
ordering (not locale collation). Search covers names, descriptions, collections and specification values using
Convex token/prefix search,
relevance order, at most 200 characters/16 words. It is not arbitrary substring
search; update storefront behavior/labels accordingly. Search with name sorting,
or slug ordering with filters, is rejected. Component full-text search supports a
bounded matching window of at most 100 records/4 MiB; broader searches return a
typed refine-search error before any partial result. Add a category/material or
more words. This explicit cap avoids a full scan/replica when component-native
search cursors are unavailable. No page length is a total count.

Cursors bind tenant, route, API version, normalized filters, sort and limit. Reset
on any change. Hidden categories are checked live within each query; a page can be
short/empty with a continuation cursor when publication changes. Follow the cursor
rather than inferring completion from its page length. Pages are not a snapshot.

The HTTP gateway returns catalog JSON `no-store`. Native shared cache enablement
is an operator release step; initial deployment stays uncached until deployed
freshness/failure acceptance is authorized and recorded. Once enabled, catalog
TTL is 30 seconds, search 15 seconds, availability 5 seconds, with a five-second
fill deadline and no stale-on-error. Private checkout always recomputes live values.

`diagnostics.loadedAt` is the original client receipt time. TanStack route reuse
must not exceed 30 seconds (search 15, availability 5), or renew that timestamp on
navigation/error. Focus/visibility return should refresh active stale loaders.
Preserve intent prefetch, scroll restoration, SSR/JSON `no-store`, CSRF, locale
redirects, and request-scoped CSP nonces. Approximately 65-second navigation age is
a budget when shared caching is enabled, not continual revocation of rendered pages.

Use derivative URLs for srcset/sizes and thumbnail controls. Retain original URLs
for intentional zoom. Images lacking a manifest fall back to their original. Public
immutable derivative URLs permit one-year browser reuse; shared copies may persist
24 hours after withdrawal. Use a separate private policy for sensitive assets.
