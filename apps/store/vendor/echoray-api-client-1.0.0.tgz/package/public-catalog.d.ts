export type {CatalogRequest,CatalogResult,PublicCard,PublicImage,DisplayManifest} from './contracts.js';
import type {CatalogRequest,CatalogResult,PublicImage} from './contracts.js';
export declare const PUBLIC_CATALOG_VERSION=1;
export type CatalogSuccess=Extract<CatalogResult,{status:'ok'}>;
export type CatalogDiagnostics={cache:string;environment:string;generatedAt:number;loadedAt:number;originMs:number|null};
export type CatalogResponse<K extends CatalogRequest['route']>=Omit<CatalogSuccess,'data'>&{data:Extract<CatalogSuccess['data'],{kind:K}>;diagnostics:CatalogDiagnostics};
export type CatalogFetchBinding={fetch(request:Request):Promise<Response>};
export declare class CatalogError extends Error {code:string;status:number;retryAfterSeconds:number|null;constructor(code:string,status:number,message:string,retryAfterSeconds?:number|null);get restartPagination():boolean;}
export type PublicCatalogClientOptions={gatewayUrl:string;storefrontId:string;binding?:CatalogFetchBinding;fetch?:typeof globalThis.fetch;onDiagnostics?:(diagnostics:CatalogDiagnostics)=>void};
export type CatalogPage={cursor?:string;limit?:number};
export type PublicCatalogClient={
 read<K extends CatalogRequest['route']>(input:CatalogRequest&{route:K},signal?:AbortSignal):Promise<CatalogResponse<K>>;
 bootstrap(page?:CatalogPage,signal?:AbortSignal):Promise<CatalogResponse<'bootstrap'>>;
 collections(page?:CatalogPage,signal?:AbortSignal):Promise<CatalogResponse<'collections'>>;
 products(filters?:Pick<CatalogRequest,'cursor'|'limit'|'collection'|'material'|'search'|'sort'>,signal?:AbortSignal):Promise<CatalogResponse<'products'>>;
 detail(slug:string,signal?:AbortSignal):Promise<CatalogResponse<'detail'>>;
 availability(productIds:string[],signal?:AbortSignal):Promise<CatalogResponse<'availability'>>;
 sitemap(page?:CatalogPage,signal?:AbortSignal):Promise<CatalogResponse<'sitemap'>>;
 imageUrl(image:PublicImage,preset:'thumbnail'|'card'|'detail'):string;
};
export declare function createPublicCatalogClient(options:PublicCatalogClientOptions):PublicCatalogClient;
